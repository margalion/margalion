# LINK UUIDGEN : https://www.uuidgenerator.net/
# FREE PROXYIP : https://raw.githubusercontent.com/SonzaiEkkusu/EDtunnel/main/443.txt
# CEK REGION PROXYIP : https://ip2geo.org/
## Deploy in worker.dev
   [![Deploy to Cloudflare Workers](https://deploy.workers.cloudflare.com/button)](https://deploy.workers.cloudflare.com/?url=https://github.com/SonzaiEkkusu/EDtunnel)
